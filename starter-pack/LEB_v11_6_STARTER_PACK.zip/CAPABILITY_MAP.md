# LEB Capability Map

Core Build - Engine construction - Engine preview and finalize

Diagnostics - Schema health - Runtime diagnostics

Performance - Token footprint - Context endurance - Monolith review

Personality - Agent DNA profiles - Molecular personality matrix

Cognition - Reasoning policies - Decision evaluation

Optimization - Bake-offs - Feature matrices

Ecosystem - Multi-engine coordination

Marketplace - Capability publishing

Economy - Workload auctions

Simulation - Civilization-scale simulations

World Model - Strategic forecasting

UX Layer - Start routing - Quickstart wizard - Suggestion engine
